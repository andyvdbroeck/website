<?php

$dbHost = "localhost";
$dbUsername = "andyvdb";
$dbPassword = "Andy30061980";
$dbName = "ftprules";

$conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search files</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <script>
        function goToPage(page) {
            document.getElementById("currentPage").value = page;
            document.searchForm.submit();
        }

        function sortBy(sortField) {
            var currentSort = document.getElementById("currentSort").value;
            var newSort = currentSort == "asc" ? "desc" : "asc";
            document.getElementById("currentSort").value = newSort;
            document.getElementById("sortField").value = sortField;
            document.searchForm.submit();
        }

        function reset() {
            document.getElementById("currentPage").value = 1;
            document.getElementById("search").value = document.getElementById("search2").value;
            document.searchForm.submit();
        }
    </script>
</head>
<body>
<div style="float:right"><a href="server.php">Add FTP server</a></div>
    <h1>Search Files</h1>

    <form id="searchForm" name="searchForm" method="POST" action="search.php">
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentPage = $_POST['currentPage'];
    $currentSort = $_POST['currentSort'];
    $sortField = $_POST['sortField'];
    $search = $_POST['search'];

    echo '<input type="hidden" id="currentPage" name="currentPage" value="'.$currentPage.'"/>'. PHP_EOL;
    echo '<input type="hidden" id="currentSort" name="currentSort" value="'.$currentSort.'"/>'. PHP_EOL;
    echo '<input type="hidden" id="sortField" name="sortField" value="'.$sortField.'"/>'. PHP_EOL;
    echo '<input type="hidden" id="search" name="search" value="'.$search.'"/>'. PHP_EOL;
    echo '<table><tr>'. PHP_EOL;
    echo '<td><label for="Search">Search:</label></td>'. PHP_EOL;
    echo '<td><input type="text" id="search2" value="'.$search.'" autofocus/></td>'. PHP_EOL;
    echo '<td><a onclick="reset()" style="margin-left: 40px;">enter</a></td>'. PHP_EOL;
    echo '</tr></table><br/>'. PHP_EOL;

    $search = mysqli_real_escape_string($conn,str_replace(" ","%",$search));

    $sql = "SELECT COUNT(*) FROM file f INNER JOIN server s on s.id = f.serverId WHERE location like '%$search%'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_row($result);
    mysqli_free_result($result);

    $count = $row[0];
    echo $count . " results<br/>";
    $amount = 25;
    $max = 40;
    if($count < 1000) {
       $max = $count / $amount;
       if($count % $amount != 0) $max = $max + 1;
    }
    $start = $amount * ($currentPage - 1);

    function shortSize($size) {
       $s = $size."";
       $slen = strlen($s);
	if($slen < 4) {
	   $s .=" Bytes";
	} else if ($slen < 7) {
	   $s = substr($s,0,$slen-3) . "," . $s[($slen-3)] . " KB";
	} else if ($slen < 10) {
	   $s = substr($s,0,$slen-6) . "," . $s[($slen-6)] . " MB";
	} else if ($slen < 13) {
	   $s = substr($s,0,$slen-9) . "," . $s[($slen-9)] . " GB";
	} else {
	   $s = substr($s,0,$slen-12) . "," . $s[($slen-12)] . " TB";
	}
	return $s;
    }

    $sql = "SELECT f.location,f.size,s.host,s.port,s.username,s.password FROM file f INNER JOIN server s on s.id = f.serverId WHERE active = true and location like '%$search%' order by $sortField $currentSort limit $start,$amount";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        echo "<table>" . PHP_EOL;
        echo "<tr><td><a onclick=\"sortBy('location')\">location</a></td><td><a onclick=\"sortBy('size')\">size</a></td></tr>" . PHP_EOL;
        while($row = mysqli_fetch_assoc($result)) {
           echo "<tr><td><a href='ftp://".urlencode($row["username"]).":".urlencode($row["password"])."@". $row["host"].":" . $row["port"] . $row["location"]. "'>". $row["location"] ."</a></td><td>" . shortSize($row["size"]) . "</td>" . PHP_EOL;
        }
        echo "</table>" . PHP_EOL;
        for ($x = 1; $x <= $max; $x++) {
           if($x != $currentPage) {
              echo '<a onclick="goToPage('.$x.')">'.$x.'</a>&nbsp;';
           }
           echo PHP_EOL;
        }
    }
    mysqli_free_result($result);
} else {
    echo '<input type="hidden" id="currentPage" name="currentPage" value="1"/>'. PHP_EOL;
    echo '<input type="hidden" id="currentSort" name="currentSort" value="asc"/>'. PHP_EOL;
    echo '<input type="hidden" id="sortField" name="sortField" value="location"/>'. PHP_EOL;
    echo '<input type="hidden" id="search" name="search" value=""/>'. PHP_EOL;
    echo '<table><tr>'. PHP_EOL;
    echo '<td><label for="Search">Search:</label></td>'. PHP_EOL;
    echo '<td><input type="text" id="search2" autofocus/></td>'. PHP_EOL;
    echo '<td><a onclick="reset()" style="margin-left: 40px;">enter</a></td>'. PHP_EOL;
    echo '</tr></table>'. PHP_EOL;
}

mysqli_close($conn);
?>
    </form>
</body>
</html>