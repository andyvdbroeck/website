<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function listDirectory($ftpConn,$directory,& $array) {
        // Verkrijg een lijst met bestanden op de FTP-server
        $fileList = ftp_nlist($ftpConn, $directory);
        foreach ($fileList as $file) {
            if($file != "." and $file != "..") {
                $size = ftp_size($ftpConn, $file);
                if($size == -1) {
                    listDirectory($ftpConn,$file,$array);
                } else {
                    $array[count($array)] = $size.','.$file;
                }
            }
        }
    }

    function getFiles($hostname,$port,$username,$password,$directory) {
        $array = array();
        // Maak een FTP-verbinding
        $ftpConn = ftp_connect($hostname, $port);
        if (!$ftpConn) {
            return $array;
        }
        // Log in op de FTP-server
        $login = ftp_login($ftpConn, $username, $password);
        if (!$login) {
            return $array;
        }
        listDirectory($ftpConn,$directory,$array);
        // Sluit de FTP-verbinding
        ftp_close($ftpConn);
        return $array;
    }

    class workerThread extends Thread {
        public function run(){
            $hostname = $_POST['hostname'];
            $port = 21;
            if (is_numeric($_POST['port'])) {
                $port = intval($_POST['port']);
            }
            $username = $_POST['username'];
            $password = $_POST['password'];
            $directory = $_POST['directory'];
            $arr = getFiles($hostname,$port,$username,$password,$directory);

            $dbHost = "localhost";
            $dbUsername = "andyvdb";
            $dbPassword = "Andy30061980";
            $dbName = "ftprules";
            $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
            if (!$conn) {
                die("Database connection failed: " . mysqli_connect_error());
            }
            $host = mysqli_real_escape_string($conn,$hostname);
            $user = mysqli_real_escape_string($conn,$username);
            $pass = mysqli_real_escape_string($conn,$password);
            $dir = mysqli_real_escape_string($conn,$directory);
            if(count($arr) > 0) {
		mysqli_query($conn,"UPDATE server SET port = $port,username = '$user',password = '$pass',directory = '$dir',online = true WHERE host = '$host'");
                preg_match_all('!\d+!', $conn->info, $m);
                if($m[0][0] == 0) {
                    echo "Dit is een test:" . $conn->error;
                    mysqli_query($conn,"INSERT INTO server(host,port,username,password,directory,online) VALUES('$host',$port,'$user','$pass','$dir',true)");
                }
                $sql = "SELECT id FROM server WHERE host = '$host'";
                $result = mysqli_query($conn,$sql);
                $row = mysqli_fetch_row($result);
                mysqli_free_result($result);
                $serverId = $row[0];
                mysqli_query($conn,"UPDATE file SET active = false WHERE serverId = $serverId");
                $arr_length = count($arr);
                for($i=0;$i<$arr_length;$i++) {
                    $pos = strpos($arr[$i], ",");
                    $location = mysqli_real_escape_string($conn,substr($arr[$i],($pos+1)));
                    $size = substr($arr[$i],0,$pos);
                    mysqli_query($conn,"UPDATE file SET size = $size,active = true WHERE location = '$location' and serverId = $serverId");
                    if(mysqli_affected_rows($conn) == 0) {
                        mysqli_query($conn,"INSERT INTO file(location,size,active,serverId) VALUES('$location',$size,true,$serverId)");
                    }
                }
            } else {
                mysqli_query($conn,"UPDATE server SET online = false WHERE host = '$host'");
            }
            mysqli_close($conn);
        }
    }
    $worker=new workerThread();
    $worker->start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add FTP Server</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>
<body>
<div style="float:right"><a href="search.php">Search files</a></div>
    <h1>Add FTP Server</h1>
    <form name="serverForm" method="POST" action="server.php">
	<table><tr>
        <td><label for="hostname">Hostname or IP:</label></td>
        <td><input type="text" name="hostname" id="hostname" required autofocus></td>
	</tr><tr>
        <td><label for="port">Port:</label></td>
        <td><input type="text" name="port" id="port" value="21" required></td>
	</tr><tr>
        <td><label for="username">Username:</label></td>
        <td><input type="text" name="username" id="username" value="anonymous" required></td>
	</tr><tr>
        <td><label for="password">Password:</label></td>
        <td><input type="text" name="password" id="password" value="andy.vdbroeck@gmail.com" required></td>
	</tr><tr>
        <td><label for="directory">Directory:</label></td>
        <td><input type="text" name="directory" id="directory" value="/" required></td>
	</tr><tr>
        <td colspan=2><a onclick="document.serverForm.submit();">add</a></td>
	</tr></table>
    </form>
</body>
</html>