<?php

$dbHost = "localhost";
$dbUsername = "andyvdb";
$dbPassword = "Andy30061980";
$dbName = "ftprules";

$conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search files</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>
<body>
<div style="float:right"><a href="server.php">Add FTP server</a></div>
    <h1>Search Files</h1>

    <form id="searchForm" name="searchForm" method="POST" action="search.php">
        <input type="hidden" id="currentPage" name="currentPage" value="1"/>
        <input type="hidden" id="sortField" name="sortField" value="location"/>
        <input type="hidden" id="currentSort" name="currentSort" value="asc"/>
        <table><tr>
        <td><label for="Search">Search:</label></td>
        <td><input type="text" id="search" name="search" value="" autofocus/></td>
        <td><a onclick="document.searchForm.submit();" style="margin-left: 40px;">enter</a></td>
        </tr></table>
    </form>
<?php

function shortSize($size) {
   $s = $size."";
   $slen = strlen($s);
   if($slen < 4) {
      $s .=" Bytes";
   } else if ($slen < 7) {
      $s = substr($s,0,$slen-3) . "," . $s[($slen-3)] . " KB";
   } else if ($slen < 10) {
      $s = substr($s,0,$slen-6) . "," . $s[($slen-6)] . " MB";
   } else if ($slen < 13) {
      $s = substr($s,0,$slen-9) . "," . $s[($slen-9)] . " GB";
   } else {
      $s = substr($s,0,$slen-12) . "," . $s[($slen-12)] . " TB";
   }
   return $s;
}

$sql = "SELECT COUNT(*),COALESCE(SUM(size),0) FROM file";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
mysqli_free_result($result);
echo $row[0]." files (". shortSize($row[1]) .")<br/>";

$sql = "SELECT COUNT(*) FROM server";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
mysqli_free_result($result);
echo $row[0]." servers<br/>";

$sql = "SELECT amount FROM visitor where year = ".date('Y');
$result = mysqli_query($conn,$sql);
$row_cnt = mysqli_num_rows($result);
if($row_cnt == 0) {
  $sql = "INSERT INTO visitor(year,amount) values(".date('Y').",1)";
  mysqli_query($conn,$sql);
  echo "1 visitors<br/>";
} else {
  $row = mysqli_fetch_row($result);
  mysqli_free_result($result);
  $sql = "UPDATE visitor SET amount = amount+1 WHERE year = ".date('Y');
  mysqli_query($conn,$sql);
  echo ($row[0]+1)." visitors<br/>";
}

mysqli_close($conn);
?>
</body>
</html>