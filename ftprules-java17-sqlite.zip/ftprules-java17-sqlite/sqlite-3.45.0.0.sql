-- SQLite script voor de database 'ftprules'

-- Tabel voor de servergegevens
CREATE TABLE IF NOT EXISTS server (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    host VARCHAR(255) NOT NULL,
    port INTEGER DEFAULT 21,
    username VARCHAR(255) DEFAULT 'anonymous',
    password VARCHAR(255) DEFAULT 'andy.vdbroeck@gmail.com',
    directory VARCHAR(255) DEFAULT '/',
    online BOOLEAN DEFAULT 1,
    UNIQUE (host)
);

-- Tabel voor de bestandsgegevens
CREATE TABLE IF NOT EXISTS file (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    location VARCHAR(255) NOT NULL,
    size INTEGER NOT NULL,
    active BOOLEAN DEFAULT 1,
    serverId INTEGER NOT NULL,
    UNIQUE (location, serverId),
    FOREIGN KEY (serverId) REFERENCES server(id)
);

-- Tabel voor bezoekersgegevens
CREATE TABLE IF NOT EXISTS visitor (
    year INTEGER NOT NULL DEFAULT 2023,
    amount INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(year)
);

