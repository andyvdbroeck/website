package model;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;


/**
 * The persistent class for the file database table.
 */
@Entity
@NamedQueries({
@NamedQuery(name="File.countFiles", query="SELECT count(f) FROM File f WHERE LOWER(f.location) like :search AND f.active = 'Y'"),
@NamedQuery(name="File.searchFiles-location-desc",query="SELECT f FROM File f WHERE LOWER(f.location) like :search AND f.active = 'Y' ORDER BY f.location DESC"),
@NamedQuery(name="File.searchFiles-location-asc",query="SELECT f FROM File f WHERE LOWER(f.location) like :search AND f.active = 'Y' ORDER BY f.location ASC"),
@NamedQuery(name="File.searchFiles-size-desc",query="SELECT f FROM File f WHERE LOWER(f.location) like :search AND f.active = 'Y' ORDER BY f.size DESC"),
@NamedQuery(name="File.searchFiles-size-asc",query="SELECT f FROM File f WHERE LOWER(f.location) like :search AND f.active = 'Y' ORDER BY f.size ASC"),
@NamedQuery(name="File.putFilesInActiveOfServer",query="UPDATE File f SET f.active = cast('N' as java.lang.Character) WHERE f.server.id = :serverId"),
@NamedQuery(name="File.getByLocationAndServerId",query="SELECT f FROM File f WHERE f.server.id = :serverId and f.location = :location")
})
public class File implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

    @Column(name = "active", columnDefinition = "char(1) default 'Y'")
	private char active;

    @Column(name = "location", nullable = false)
	private String location;

    @Column(name = "size", nullable = false)
	private Long size;

	//bi-directional many-to-one association to Server
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="serverId", referencedColumnName = "id")
	private Server server;

	public File() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public char getActive() {
		return this.active;
	}

	public void setActive(char active) {
		this.active = active;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Long getSize() {
		return this.size;
	}
	
	public String getShortSize() {
		String s = this.size+"";
		if(s.length()<4) {
			s +=" Bytes";
		} else if (s.length()<7) {
			s = s.substring(0,s.length()-3) + "," + s.charAt(s.length()-3) + " KB";
		} else if (s.length()<10) {
			s = s.substring(0,s.length()-6) + "," + s.charAt(s.length()-6) + " MB";
		} else if (s.length()<13) {
			s = s.substring(0,s.length()-9) + "," + s.charAt(s.length()-9) + " GB";
		} else {
			s = s.substring(0,s.length()-12) + "," + s.charAt(s.length()-12) + " TB";
		}
		
		return s;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public Server getServer() {
		return this.server;
	}

	public void setServer(Server server) {
		this.server = server;
	}

}