package model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;


/**
 * The persistent class for the server database table.
 */
@Entity
@NamedQueries({
@NamedQuery(name="Server.findAll", query="SELECT s FROM Server s"),
@NamedQuery(name="Server.getByHost",query="SELECT s FROM Server s WHERE s.host = :host"),
})
public class Server implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

    @Column(name = "directory", columnDefinition = "varchar(255) default '/'")
	private String directory;

    @Column(name = "host", nullable = false)
	private String host;

    @Column(name = "online", columnDefinition = "char(1) default 'Y'")
	private char online;

    @Column(name = "\"password\"", columnDefinition = "varchar(320) default 'andy.vdbroeck@gmail.com'")
	private String password;

    @Column(name = "port", columnDefinition = "int default 21")
	private Integer port;

    @Column(name = "\"user\"", columnDefinition = "varchar(255) default 'anonymous'")
	private String user;

	//bi-directional many-to-one association to File
	@OneToMany(mappedBy="server",fetch = FetchType.LAZY)
	private List<File> files;

	public Server() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDirectory() {
		return this.directory;
	}

	public void setDirectory(String directory) {
		this.directory = directory;
	}

	public String getHost() {
		return this.host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public char getOnline() {
		return this.online;
	}

	public void setOnline(char online) {
		this.online = online;
	}

	public String getEncodedPassword() {
		String p = this.password;
		try {
			p = URLEncoder.encode(this.password, "UTF-8");
		} catch (UnsupportedEncodingException e) {}
		return p;
	}
	
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getPort() {
		return this.port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getEncodedUser() {
		String p = this.user;
		try {
			p = URLEncoder.encode(this.user, "UTF-8");
		} catch (UnsupportedEncodingException e) {}
		return p;
	}

	public String getUser() {
		return this.user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public List<File> getFiles() {
		return this.files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public File addFile(File file) {
		getFiles().add(file);
		file.setServer(this);

		return file;
	}

	public File removeFile(File file) {
		getFiles().remove(file);
		file.setServer(null);

		return file;
	}

}