package session;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import model.File;
import model.Server;

/**
 * Session Bean implementation class ServerDAO
 */
@Stateless
public class ServerDAO {
	@PersistenceContext(unitName = "my-persistence-unit")
	private EntityManager entityManager;

	private void create(Server server) {
		entityManager.persist(server);
	}

	private Server update(Server server) {
		return entityManager.merge(server);
	}

	private Server getByHost(String host) {
		try {
			TypedQuery<Server> query = entityManager.createNamedQuery("Server.getByHost",Server.class).setParameter("host", host);
			return query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public void addServer(Server server) {
		Server s = getByHost(server.getHost());
		if(null == s) {
			create(server);
		} else {
			server.setId(s.getId());
			update(server);
		}
	}
	
	private void putOffline(final String host) {
		Server server = getByHost(host);
		if(server !=null) {
			server.setOnline('N');
			update(server);
		}
	}
	
	private void putFilesInActiveOfServer(Integer serverId) {
		entityManager.createNamedQuery("File.putFilesInActiveOfServer").setParameter("serverId", serverId).executeUpdate();
	}
	
	private void create(File file) {
		File f = getByLocationAndServerId(file.getLocation(), file.getServer().getId());
		if(f==null)
			entityManager.persist(file);
		else {
			file.setId(f.getId());
			entityManager.merge(file);
		}
	}

	private File getByLocationAndServerId(String location, Integer serverId) {
		try {
			TypedQuery<File> query = entityManager.createNamedQuery("File.getByLocationAndServerId", File.class).setParameter("location", location).setParameter("serverId", serverId);
			return query.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public void putFilesInServer(List<String> list, Server server) {
		Server s = getByHost(server.getHost());
		if(s != null) {
			putFilesInActiveOfServer(s.getId());
		}
		if (list.isEmpty()) {
			putOffline(server.getHost());
		} else {
			for (String f : list) {
				String location = f.substring(0, f.lastIndexOf(','));
				Long size = Long.valueOf(f.substring(f.lastIndexOf(',') + 1));
				File file = new File();
				file.setLocation(location);
				file.setSize(size);
				file.setActive('Y');
				file.setServer(s);
				create(file);
			}
		}
	}
}
