package session;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import model.File;

/**
 * Session Bean implementation class FileDAO
 */
@Stateless
public class FileDAO {
	@PersistenceContext(unitName = "my-persistence-unit")
	private EntityManager entityManager;

	public long countFiles(String search) {
		TypedQuery<Long> query = entityManager.createNamedQuery("File.countFiles", Long.class).setParameter("search", "%"+search.toLowerCase().replace(" ", "%")+"%");
		return query.getSingleResult();
	}
	
	public List<File> searchFiles(String search,int start,int amount,String sortField,String currentSort) {
		TypedQuery<File> query = entityManager.createNamedQuery("File.searchFiles-"+sortField+"-"+currentSort, File.class);
		query.setParameter("search", "%"+search.toLowerCase().replace(" ", "%")+"%");
		query.setFirstResult(start);
		query.setMaxResults(amount);
		return query.getResultList();
	}

}
