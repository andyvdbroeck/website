package utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

public class FtpClient {
	
	private static void listDirectory(FTPClient ftpClient, String parentDir, String currentDir, ArrayList<String> list) throws IOException {
		String dirToList = parentDir;
		if (!currentDir.equals("")) {
			dirToList += "/" + currentDir;
		}
		FTPFile[] subFiles = ftpClient.listFiles(dirToList);
		if (subFiles != null && subFiles.length > 0) {
			for (FTPFile aFile : subFiles) {
				String currentFileName = aFile.getName();
				if (currentFileName.equals(".") || currentFileName.equals("..")) {
					// skip parent directory and directory itself
					continue;
				}
				if (aFile.isDirectory()) {
					listDirectory(ftpClient, dirToList, currentFileName,list);
				} else {
					list.add((dirToList+"/"+currentFileName).replace("//", "/")+","+aFile.getSize());
				}
			}
		}
	}
	
	public static List<String> getFiles(String host,int port,String user,String password,String directory) {
		FTPClient ftpClient = new FTPClient();
		ArrayList<String> list = new ArrayList<String>();
		try {
			ftpClient.connect(host, port);
			int replyCode = ftpClient.getReplyCode();
			if (!FTPReply.isPositiveCompletion(replyCode)) {
				return list;
			}
			boolean success = ftpClient.login(user, password);
			if (!success) {
				return list;
			}
			listDirectory(ftpClient, directory, "",list);
		} catch (IOException ex) {
		} finally {
			// logs out and disconnects from server
			try {
				if (ftpClient.isConnected()) {
					ftpClient.logout();
					ftpClient.disconnect();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return list;
	}
}

