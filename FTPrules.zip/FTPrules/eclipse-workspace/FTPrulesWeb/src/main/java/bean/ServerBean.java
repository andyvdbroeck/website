package bean;

import java.util.List;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import model.Server;
import session.ServerDAO;
import utils.FtpClient;

@Named
@SessionScoped
public class ServerBean implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private String host = null;
	private int port = 21;
	private String user = "anonymous";
	private String password = "andy.vdbroeck@gmail.com";
	private String directory = "/";

	@EJB
	private ServerDAO serverDAO;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		if(host != null) {
			this.host = host.trim();
		} else {
			this.host = null;
		}
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		if(user != null) {
			this.user = user.trim();
		} else {
			this.user = null;
		}
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		if(password != null) {
			this.password = password.trim();
		} else {
			this.password = null;
		}
	}

	public String getDirectory() {
		return directory;
	}

	public void setDirectory(String directory) {
		if(directory != null) {
			this.directory = directory.trim().replace("\\", "/");
			if(directory.charAt(0) !='/') {
				directory = "/" + directory;
			}
		} else {
			this.directory = null;
		}
	}

	public void addServer() {
		Server server = new Server();
		server.setHost(host);
		server.setPort(port);
		server.setUser(user);
		server.setPassword(password);
		server.setDirectory(directory);
		server.setOnline('Y');

		serverDAO.addServer(server);

		new Thread() {
			public void run() {
				List<String> list = FtpClient.getFiles(server.getHost(), server.getPort(), server.getUser(),
						server.getPassword(), server.getDirectory());
				serverDAO.putFilesInServer(list,server);
			}
		}.start();

		// Clear input fields
		host = null;
		port = 21;
		user = "anonymous";
		password = "andy.vdbroeck@gmail.com";
		directory = "/";
		// Show success message
		FacesMessage message = new FacesMessage("Server added successfully");
		FacesContext.getCurrentInstance().addMessage(null, message);
	}
}