package bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import model.File;
import session.FileDAO;

@Named
@SessionScoped
public class FileBean implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private String search="";
	private Integer currentPage=1;
	private String currentSort="asc";
	private String sortField="location";

    private List<File> files = new ArrayList<File>();
    private List<Integer> pageNumbers = new ArrayList<Integer>();

    @EJB
    private FileDAO fileDAO;

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public List<File> getFiles() {
        return files;
    }

    public void setFiles(List<File> files) {
        this.files = files;
    }

    public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public String getCurrentSort() {
		return currentSort;
	}

	public void setCurrentSort(String currentSort) {
		this.currentSort = currentSort;
	}

	public String getSortField() {
		return sortField;
	}

	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	public List<Integer> getPageNumbers() {
		return pageNumbers;
	}

	public void setPageNumbers(List<Integer> pageNumbers) {
		this.pageNumbers = pageNumbers;
	}

	public void searchFiles() {
		int amount = 25;
		long count = fileDAO.countFiles(search);
		long max = count / amount;
		if(count%amount != 0) max++;
		pageNumbers = new ArrayList<Integer>();
		for(int i=1;i<=max;i++) {
			if(currentPage != i) {
				pageNumbers.add(i);
			}
		}
		Collections.sort(pageNumbers);
		int start = amount*(currentPage-1);
        files = fileDAO.searchFiles(search,start,amount,sortField,currentSort);
        if (files.isEmpty()) {
            FacesMessage message = new FacesMessage("No files found");
            FacesContext.getCurrentInstance().addMessage(null, message);
        } else {
            FacesMessage message = new FacesMessage("Files found:" + count);
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
}
